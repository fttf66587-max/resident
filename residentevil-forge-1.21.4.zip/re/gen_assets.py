import json, os
from PIL import Image, ImageDraw
NS="residentevil"; R=f"src/main/resources"
A=f"{R}/assets/{NS}"; D=f"{R}/data/{NS}"
for p in ["items","models/item","textures/item","textures/entity","lang"]: os.makedirs(f"{A}/{p}",exist_ok=True)
for p in ["recipe","loot_table","forge/biome_modifier"]: os.makedirs(f"{D}/{p}",exist_ok=True)
def w(path,obj): open(path,"w",encoding="utf-8").write(json.dumps(obj,ensure_ascii=False,indent=1))

# ---------- предметы ----------
items={ # id: (en, ru)
"handgun":("Matilda Handgun","Пистолет «Матильда»"),"shotgun":("W-870 Shotgun","Дробовик W-870"),
"magnum":("Lightning Hawk Magnum","Магнум «Lightning Hawk»"),"combat_knife":("Combat Knife","Боевой нож"),
"handgun_ammo":("Handgun Ammo","Патроны 9мм"),"shotgun_shells":("Shotgun Shells","Дробовые патроны"),
"magnum_ammo":("Magnum Ammo","Патроны .50"),"green_herb":("Green Herb","Зелёная трава"),
"red_herb":("Red Herb","Красная трава"),"mixed_herb":("Mixed Herb (G+R)","Смесь трав"),
"first_aid_spray":("First Aid Spray","Аптечка-спрей"),"t_virus_vial":("T-Virus Vial","Ампула T-вируса"),
}
eggs={"leon":("Leon S. Kennedy","Леон Кеннеди",(0x6b5a3c,0x3a4a5a)),"ada":("Ada Wong","Ада Вонг",(0x111111,0xb0121b)),
"jill":("Jill Valentine","Джилл Валентайн",(0x4a3320,0x2a5ea8)),"chris":("Chris Redfield","Крис Редфилд",(0x2d3b57,0xc0a060)),
"wesker":("Albert Wesker","Альберт Вескер",(0x0a0a0a,0xd8d8a0)),"nemesis":("Nemesis T-Type","Немезис",(0x2e3a2e,0xaa1111)),
"dimitrescu":("Lady Dimitrescu","Леди Деметреску",(0xf0f0f0,0x111111)),"baker":("Jack Baker","Джек Бейкер",(0x6e6e60,0x8a4a2a)),
"zombie":("Infected Zombie","Заражённый",(0x5a7a5a,0x3a3a50))}

def icon(name):
    im=Image.new("RGBA",(16,16),(0,0,0,0)); d=ImageDraw.Draw(im)
    if name in("handgun","magnum"):
        c=(50,50,55) if name=="handgun" else (170,170,180)
        d.rectangle([2,4,13,6],fill=c); d.rectangle([2,6,5,7],fill=c); d.rectangle([3,7,6,12],fill=(90,60,40)); d.point((13,4),fill=(255,255,255))
    elif name=="shotgun":
        d.rectangle([1,6,14,7],fill=(60,60,65)); d.rectangle([1,8,9,8],fill=(60,60,65)); d.rectangle([9,7,14,10],fill=(110,70,40)); d.rectangle([11,10,13,12],fill=(110,70,40))
    elif name=="combat_knife":
        for i in range(9): d.point((3+i,12-i),fill=(200,205,215)); d.point((4+i,12-i),fill=(150,155,165))
        d.rectangle([2,12,4,14],fill=(30,30,30))
    elif name.endswith("ammo") or name=="shotgun_shells":
        col={"handgun_ammo":(220,180,60),"shotgun_shells":(200,40,40),"magnum_ammo":(230,230,240)}[name]
        for x in (3,7,11): d.rectangle([x,4,x+2,12],fill=col); d.rectangle([x,4,x+2,6],fill=(120,90,40))
    elif "herb" in name:
        col={"green_herb":(40,170,60),"red_herb":(200,30,40),"mixed_herb":(150,120,50)}[name]
        d.line([8,14,8,5],fill=(30,100,30)); d.ellipse([3,2,8,7],fill=col); d.ellipse([8,2,13,7],fill=col); d.ellipse([5,6,11,11],fill=col)
        if name=="mixed_herb": d.ellipse([8,2,13,7],fill=(200,30,40))
    elif name=="first_aid_spray":
        d.rectangle([5,5,10,14],fill=(130,60,170)); d.rectangle([6,2,9,4],fill=(220,220,220)); d.rectangle([7,8,8,11],fill=(255,255,255)); d.rectangle([6,9,9,10],fill=(255,255,255))
    elif name=="t_virus_vial":
        d.rectangle([6,3,9,5],fill=(60,60,60)); d.rectangle([5,6,10,14],fill=(210,60,60,230)); d.rectangle([6,6,9,8],fill=(255,150,150))
    return im
def egg_icon():
    im=Image.new("RGBA",(16,16),(0,0,0,0)); d=ImageDraw.Draw(im); d.ellipse([3,1,12,14],fill=(255,255,255)); d.ellipse([5,6,10,10],fill=(160,160,160)); return im

for n,(en,ru) in items.items():
    icon(n).save(f"{A}/textures/item/{n}.png")
    w(f"{A}/models/item/{n}.json",{"parent":"minecraft:item/handheld" if n in("handgun","shotgun","magnum","combat_knife") else "minecraft:item/generated","textures":{"layer0":f"{NS}:item/{n}"}})
    w(f"{A}/items/{n}.json",{"model":{"type":"minecraft:model","model":f"{NS}:item/{n}"}})
for n,(en,ru,(c1,c2)) in eggs.items():
    w(f"{A}/items/{n}_spawn_egg.json",{"model":{"type":"minecraft:model","model":"minecraft:item/template_spawn_egg","tints":[{"type":"minecraft:constant","value":c1},{"type":"minecraft:constant","value":c2}]}})

# ---------- скины 64x64 ----------
def skin(name,skin_c,hair,top,bottom,eyes=(20,20,20),visor=None,extra=None):
    im=Image.new("RGBA",(64,64),(0,0,0,0)); d=ImageDraw.Draw(im)
    def box(x0,y0,x1,y1,c): d.rectangle([x0,y0,x1-1,y1-1],fill=c)
    box(0,0,32,16,skin_c); box(8,0,24,8,hair); box(24,8,32,16,hair); box(0,8,8,10,hair); box(16,8,24,10,hair); box(8,8,16,10,hair)
    d.point((10,12),fill=eyes); d.point((13,12),fill=eyes)
    if visor: box(9,11,15,13,visor)
    box(16,16,40,32,top); box(40,16,56,28,top); box(40,28,56,32,skin_c)
    box(0,16,16,32,bottom); box(32,48,48,60,top); box(32,60,48,64,skin_c); box(16,48,32,64,bottom)
    if extra: extra(d,box)
    im.save(f"{A}/textures/entity/{name}.png")
skin("leon",(235,200,170),(150,120,70),(60,75,95),(70,60,50))
skin("ada",(240,215,195),(15,15,15),(176,18,27),(176,18,27))
skin("jill",(235,205,180),(90,60,35),(42,94,168),(60,60,70))
skin("chris",(225,185,150),(60,40,30),(45,60,45),(50,70,50),extra=lambda d,b:b(16,16,40,24,(30,40,70)))
skin("wesker",(230,215,200),(225,225,180),(15,15,15),(15,15,15),visor=(0,0,0),extra=lambda d,b:b(16,16,40,17,(150,0,0)))
skin("nemesis",(150,160,150),(60,60,60),(40,50,40),(30,30,30),eyes=(255,0,0),extra=lambda d,b:(b(9,10,15,11,(120,40,40)),b(18,18,22,30,(110,30,30))))
skin("dimitrescu",(245,235,235),(20,20,20),(240,240,240),(240,240,240),eyes=(200,0,0),extra=lambda d,b:b(8,0,16,4,(10,10,10)))
skin("baker",(190,185,170),(70,60,50),(110,110,100),(70,85,110),eyes=(170,0,0))
skin("zombie",(95,130,95),(40,50,40),(70,80,110),(50,50,70),eyes=(255,255,0),extra=lambda d,b:(b(20,20,28,26,(60,40,40)),b(40,16,56,20,(80,120,80))))

# ---------- язык ----------
en={f"item.{NS}.{k}":v[0] for k,v in items.items()}; ru={f"item.{NS}.{k}":v[1] for k,v in items.items()}
for k,v in eggs.items():
    en[f"item.{NS}.{k}_spawn_egg"]=v[0]+" Spawn Egg"; ru[f"item.{NS}.{k}_spawn_egg"]="Яйцо призыва: "+v[1]
    en[f"entity.{NS}.{k}"]=v[0]; ru[f"entity.{NS}.{k}"]=v[1]
en[f"itemGroup.{NS}"]="Resident Evil"; ru[f"itemGroup.{NS}"]="Resident Evil"
w(f"{A}/lang/en_us.json",en); w(f"{A}/lang/ru_ru.json",ru)

# ---------- рецепты ----------
def shaped(n,pat,key,res,cnt=1):
    w(f"{D}/recipe/{n}.json",{"type":"minecraft:crafting_shaped","category":"equipment","pattern":pat,"key":key,"result":{"id":f"{NS}:{n}","count":cnt}})
shaped("handgun",["II ","IPI"," GI"][:3] if False else ["III","  P"," G "],{"I":"minecraft:iron_ingot","P":"minecraft:iron_block","G":"minecraft:gunpowder"} ,"")
shaped("shotgun",["III","PPG","  G"],{"I":"minecraft:iron_ingot","P":"minecraft:planks","G":"minecraft:gunpowder"},"")
shaped("magnum",["IDI","IGP","  I"],{"I":"minecraft:iron_ingot","D":"minecraft:diamond","G":"minecraft:gunpowder","P":"minecraft:iron_block"},"")
shaped("combat_knife",["I","S"],{"I":"minecraft:iron_ingot","S":"minecraft:stick"},"")
def shapeless(n,ings,cnt=1):
    w(f"{D}/recipe/{n}.json",{"type":"minecraft:crafting_shapeless","category":"misc","ingredients":ings,"result":{"id":f"{NS}:{n}","count":cnt}})
shapeless("handgun_ammo",["minecraft:gunpowder","minecraft:iron_nugget","minecraft:copper_ingot"],12)
shapeless("shotgun_shells",["minecraft:gunpowder","minecraft:iron_nugget","minecraft:paper"],8)
shapeless("magnum_ammo",["minecraft:gunpowder","minecraft:gold_nugget","minecraft:iron_ingot"],6)
shapeless("mixed_herb",[f"{NS}:green_herb",f"{NS}:red_herb"])
shapeless("green_herb",["minecraft:fern","minecraft:bone_meal"])
shapeless("red_herb",["minecraft:poppy","minecraft:bone_meal"])
shapeless("first_aid_spray",[f"{NS}:mixed_herb",f"{NS}:mixed_herb","minecraft:glass_bottle"])

# ---------- спавн зомби в мире ----------
w(f"{D}/forge/biome_modifier/zombie.json",{"type":"forge:add_spawns","biomes":"#minecraft:is_overworld",
 "spawners":{"type":f"{NS}:zombie","weight":8,"minCount":2,"maxCount":4}})
