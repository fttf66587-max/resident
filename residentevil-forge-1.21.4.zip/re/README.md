# Resident Evil Mod (Forge 1.21.4)
Сборка: скопируйте `src/` в официальный Forge MDK 1.21.4 (или используйте build.gradle) → `gradlew build` → jar в build/libs.
Тест: `gradlew runClient`, вкладка творчества «Resident Evil».
