package com.residentevil;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.List;

/** Леди Деметреску: гигантка, когти вампирят здоровье, призывает мух-зомби. */
public class Dimitrescu extends REBoss {
    public Dimitrescu(EntityType<? extends Monster> t, Level l) { super(t, l, BossEvent.BossBarColor.WHITE); }
    public static AttributeSupplier.Builder createAttributes() { return stats(450, 0.30, 12, 0.7); }

    @Override protected void customServerAiStep(ServerLevel sl) {
        super.customServerAiStep(sl);
        if (getTarget() != null && tickCount % 220 == 0 &&
                sl.getEntitiesOfClass(RZombie.class, getBoundingBox().inflate(20)).size() < 4) {
            for (int i = 0; i < 2; i++) {
                ModEntities.ZOMBIE.get().spawn(sl, blockPosition().offset(random.nextInt(5) - 2, 0, random.nextInt(5) - 2), EntitySpawnReason.MOB_SUMMONED);
                sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.5, getZ(), 25, 1, 1, 1, .02);
            }
        }
    }
    @Override public boolean doHurtTarget(ServerLevel sl, Entity e) {
        boolean r = super.doHurtTarget(sl, e);
        if (r) { heal(4f); if (e instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 1)); }
        return r;
    }
    @Override protected List<ItemStack> loot() { return List.of(new ItemStack(ModItems.RED_HERB.get(), 3), new ItemStack(ModItems.FIRST_AID_SPRAY.get(), 2), new ItemStack(ModItems.T_VIRUS.get())); }
}
