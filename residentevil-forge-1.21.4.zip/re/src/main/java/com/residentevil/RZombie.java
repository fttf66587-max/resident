package com.residentevil;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;

/** Заражённый: не горит на солнце, кусается (яд + голод). */
public class RZombie extends Zombie {
    public RZombie(EntityType<? extends Zombie> t, Level l) { super(t, l); }
    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes().add(Attributes.MAX_HEALTH, 30).add(Attributes.ATTACK_DAMAGE, 5);
    }
    @Override protected boolean isSunSensitive() { return false; }
    @Override public boolean doHurtTarget(ServerLevel sl, Entity e) {
        boolean r = super.doHurtTarget(sl, e);
        if (r && e instanceof LivingEntity le) { le.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0)); le.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 1)); }
        return r;
    }
}
