package com.residentevil;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;

public class ModUtil {
    /** Hitscan-выстрел: pellets лучей со разбросом spread. */
    public static void shoot(LivingEntity shooter, Vec3 baseDir, double range, float dmg, int pellets, float spread) {
        if (!(shooter.level() instanceof ServerLevel sl)) return;
        sl.playSound(null, shooter.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.4f, 0.7f);
        Vec3 start = shooter.getEyePosition();
        for (int i = 0; i < pellets; i++) {
            Vec3 dir = baseDir.add(shooter.getRandom().nextGaussian() * spread,
                    shooter.getRandom().nextGaussian() * spread,
                    shooter.getRandom().nextGaussian() * spread).normalize();
            Vec3 end = start.add(dir.scale(range));
            BlockHitResult bhr = sl.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
            Vec3 limit = bhr.getType() == HitResult.Type.MISS ? end : bhr.getLocation();
            AABB box = shooter.getBoundingBox().expandTowards(dir.scale(range)).inflate(1);
            EntityHitResult ehr = ProjectileUtil.getEntityHitResult(shooter, start, limit, box,
                    e -> !e.isSpectator() && e.isPickable() && e != shooter, range * range);
            if (ehr != null) limit = ehr.getLocation();
            double dist = start.distanceTo(limit);
            for (double d = 1.5; d < dist; d += 1.5) {
                Vec3 p = start.add(dir.scale(d));
                sl.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
            if (ehr != null) {
                DamageSource src = shooter instanceof Player p ? sl.damageSources().playerAttack(p) : sl.damageSources().mobAttack(shooter);
                ehr.getEntity().hurtServer(sl, src, dmg);
                sl.sendParticles(ParticleTypes.DAMAGE_INDICATOR, limit.x, limit.y, limit.z, 2, 0.1, 0.1, 0.1, 0.1);
            }
        }
    }
}
