package com.residentevil;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/** Травы, спрей и T-вирус. */
public class HealItem extends Item {
    private final float heal; private final boolean tvirus;
    public HealItem(Properties p, float heal, boolean tvirus) { super(p); this.heal = heal; this.tvirus = tvirus; }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack s = player.getItemInHand(hand);
        if (!level.isClientSide) {
            player.heal(heal);
            if (tvirus) {
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 3));
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 2));
                player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 600, 2));
            }
            level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EAT.value(), SoundSource.PLAYERS, 1f, 1f);
        }
        s.consume(1, player);
        player.getCooldowns().addCooldown(s, 20);
        return InteractionResult.SUCCESS;
    }
}
