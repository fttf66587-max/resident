package com.residentevil;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ResidentEvilMod.MODID);

    private static <T extends Entity> RegistryObject<EntityType<T>> reg(String n, EntityType.EntityFactory<T> f, MobCategory c, float w, float h) {
        return ENTITIES.register(n, () -> EntityType.Builder.of(f, c).sized(w, h).clientTrackingRange(10)
                .build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(ResidentEvilMod.MODID, n))));
    }

    // Союзники
    public static final RegistryObject<EntityType<RECharacter>> LEON = reg("leon", (t, l) -> new RECharacter(t, l, 6f, 0.30), MobCategory.CREATURE, 0.6f, 1.95f);
    public static final RegistryObject<EntityType<RECharacter>> ADA = reg("ada", (t, l) -> new RECharacter(t, l, 5f, 0.36), MobCategory.CREATURE, 0.6f, 1.95f);
    public static final RegistryObject<EntityType<RECharacter>> JILL = reg("jill", (t, l) -> new RECharacter(t, l, 6f, 0.30).healer(), MobCategory.CREATURE, 0.6f, 1.95f);
    public static final RegistryObject<EntityType<RECharacter>> CHRIS = reg("chris", (t, l) -> new RECharacter(t, l, 9f, 0.27), MobCategory.CREATURE, 0.65f, 2.0f);
    // Боссы и враги
    public static final RegistryObject<EntityType<Wesker>> WESKER = reg("wesker", Wesker::new, MobCategory.MONSTER, 0.6f, 1.95f);
    public static final RegistryObject<EntityType<Nemesis>> NEMESIS = reg("nemesis", Nemesis::new, MobCategory.MONSTER, 0.85f, 2.7f);
    public static final RegistryObject<EntityType<Dimitrescu>> DIMITRESCU = reg("dimitrescu", Dimitrescu::new, MobCategory.MONSTER, 0.9f, 2.9f);
    public static final RegistryObject<EntityType<Baker>> BAKER = reg("baker", Baker::new, MobCategory.MONSTER, 0.7f, 2.05f);
    public static final RegistryObject<EntityType<RZombie>> ZOMBIE = reg("zombie", RZombie::new, MobCategory.MONSTER, 0.6f, 1.95f);
}
