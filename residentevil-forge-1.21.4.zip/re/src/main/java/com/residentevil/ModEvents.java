package com.residentevil;

import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;

public class ModEvents {
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.LEON.get(), RECharacter.createAttributes().build());
        e.put(ModEntities.ADA.get(), RECharacter.createAttributes().build());
        e.put(ModEntities.JILL.get(), RECharacter.createAttributes().build());
        e.put(ModEntities.CHRIS.get(), RECharacter.createAttributes().build());
        e.put(ModEntities.WESKER.get(), Wesker.createAttributes().build());
        e.put(ModEntities.NEMESIS.get(), Nemesis.createAttributes().build());
        e.put(ModEntities.DIMITRESCU.get(), Dimitrescu.createAttributes().build());
        e.put(ModEntities.BAKER.get(), Baker.createAttributes().build());
        e.put(ModEntities.ZOMBIE.get(), RZombie.createAttributes().build());
    }
    public static void spawnPlacements(SpawnPlacementRegisterEvent e) {
        e.register(ModEntities.ZOMBIE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
