package com.residentevil;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/** Альберт Вескер: мгновенные рывки за спину, фаза 2 — Uroboros-ярость. */
public class Wesker extends REBoss {
    private boolean phase2;
    public Wesker(EntityType<? extends Monster> t, Level l) { super(t, l, BossEvent.BossBarColor.RED); }
    public static AttributeSupplier.Builder createAttributes() { return stats(400, 0.38, 9, 0.5); }

    @Override protected void customServerAiStep(ServerLevel sl) {
        super.customServerAiStep(sl);
        LivingEntity t = getTarget();
        if (t != null && tickCount % 50 == 0 && distanceToSqr(t) > 25) {
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 1, getZ(), 30, .3, .8, .3, .1);
            Vec3 back = t.position().subtract(t.getLookAngle().scale(2));
            randomTeleport(back.x, t.getY(), back.z, true);
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 1, getZ(), 30, .3, .8, .3, .1);
        }
        if (!phase2 && getHealth() < getMaxHealth() / 2) {
            phase2 = true;
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.52);
            getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(14);
            addEffect(new MobEffectInstance(MobEffects.GLOWING, 999999, 0, false, false));
            sl.getServer().getPlayerList().broadcastSystemMessage(Component.literal("§4Вескер: «Вы всё ещё не понимаете, на что я способен!»"), false);
        }
    }
    @Override public boolean doHurtTarget(ServerLevel sl, Entity e) {
        boolean r = super.doHurtTarget(sl, e);
        if (r && e instanceof LivingEntity le) { le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1)); le.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0)); }
        return r;
    }
    @Override public boolean causeFallDamage(double d, float f, net.minecraft.world.damagesource.DamageSource s) { return false; }
    @Override protected List<ItemStack> loot() { return List.of(new ItemStack(ModItems.MAGNUM.get()), new ItemStack(ModItems.MAGNUM_AMMO.get(), 12), new ItemStack(ModItems.T_VIRUS.get(), 2)); }
}
