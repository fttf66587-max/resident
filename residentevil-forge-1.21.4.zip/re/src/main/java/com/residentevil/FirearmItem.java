package com.residentevil;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import java.util.function.Supplier;

public class FirearmItem extends Item {
    private final float damage, spread;
    private final int pellets, cooldown;
    private final double range;
    private final Supplier<Item> ammo;

    public FirearmItem(Properties p, float damage, int pellets, float spread, int cooldown, double range, Supplier<Item> ammo) {
        super(p);
        this.damage = damage; this.pellets = pellets; this.spread = spread;
        this.cooldown = cooldown; this.range = range; this.ammo = ammo;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack gun = player.getItemInHand(hand);
        if (!player.getAbilities().instabuild && !takeAmmo(player)) {
            if (!level.isClientSide) level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1f, 1.6f);
            return InteractionResult.FAIL;
        }
        if (!level.isClientSide) ModUtil.shoot(player, player.getLookAngle(), range, damage, pellets, spread);
        player.getCooldowns().addCooldown(gun, cooldown);
        return InteractionResult.SUCCESS;
    }

    private boolean takeAmmo(Player player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ammo.get())) { s.shrink(1); return true; }
        }
        return false;
    }
}
