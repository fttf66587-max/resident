package com.residentevil;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.List;

/** Джек Бейкер: регенерирует и воскресает один раз («Добро пожаловать в семью!»). */
public class Baker extends REBoss {
    private boolean revived;
    public Baker(EntityType<? extends Monster> t, Level l) { super(t, l, BossEvent.BossBarColor.YELLOW); }
    public static AttributeSupplier.Builder createAttributes() { return stats(350, 0.27, 12, 0.8); }

    @Override public boolean hurtServer(ServerLevel sl, DamageSource src, float amount) {
        if (!revived && getHealth() - amount <= 0) {
            revived = true;
            setHealth(getMaxHealth() * 0.5f);
            sl.getServer().getPlayerList().broadcastSystemMessage(Component.literal("§6Джек: «Добро пожаловать в семью, сынок!»"), false);
            return false;
        }
        return super.hurtServer(sl, src, amount);
    }
    @Override protected void customServerAiStep(ServerLevel sl) { super.customServerAiStep(sl); if (tickCount % 20 == 0) heal(1.5f); }
    @Override protected List<ItemStack> loot() { return List.of(new ItemStack(ModItems.MIXED_HERB.get(), 3), new ItemStack(ModItems.HANDGUN_AMMO.get(), 30)); }
}
