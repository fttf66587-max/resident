package com.residentevil;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.List;

/** Немезис: огромный, почти непробиваемый, топчет землю (AoE). */
public class Nemesis extends REBoss {
    private boolean roared;
    public Nemesis(EntityType<? extends Monster> t, Level l) { super(t, l, BossEvent.BossBarColor.PURPLE); }
    public static AttributeSupplier.Builder createAttributes() { return stats(600, 0.26, 18, 0.95); }

    @Override protected void customServerAiStep(ServerLevel sl) {
        super.customServerAiStep(sl);
        LivingEntity t = getTarget();
        if (t != null && !roared) {
            roared = true;
            sl.getServer().getPlayerList().broadcastSystemMessage(Component.literal("§cНемезис: «S.T.A.R.S.....»"), false);
            sl.playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3f, 0.5f);
        }
        if (t != null && tickCount % 100 == 0 && distanceToSqr(t) < 49) {
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + .2, getZ(), 12, 3, .1, 3, 0);
            sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE.value(), SoundSource.HOSTILE, 2f, 0.6f);
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(6), x -> x != this && !(x instanceof REBoss))) {
                e.hurtServer(sl, sl.damageSources().mobAttack(this), 10f);
                e.push(0, 0.9, 0); e.hurtMarked = true;
            }
        }
        if (tickCount % 40 == 0) heal(2f);
    }
    @Override protected List<ItemStack> loot() { return List.of(new ItemStack(ModItems.SHOTGUN.get()), new ItemStack(ModItems.SHOTGUN_SHELLS.get(), 24), new ItemStack(ModItems.FIRST_AID_SPRAY.get(), 2)); }
}
