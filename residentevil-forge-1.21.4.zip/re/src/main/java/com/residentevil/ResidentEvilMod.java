package com.residentevil;

import com.residentevil.client.ClientSetup;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;

@Mod(ResidentEvilMod.MODID)
public class ResidentEvilMod {
    public static final String MODID = "residentevil";

    public ResidentEvilMod(FMLJavaModLoadingContext ctx) {
        IEventBus bus = ctx.getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(ModEvents::attributes);
        bus.addListener(ModEvents::spawnPlacements);
        if (FMLEnvironment.dist.isClient()) bus.addListener(ClientSetup::renderers);
    }
}
