package com.residentevil;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import java.util.function.Function;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ResidentEvilMod.MODID);

    private static RegistryObject<Item> reg(String n, Function<Item.Properties, Item> f) {
        return ITEMS.register(n, () -> f.apply(new Item.Properties().setId(
                ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(ResidentEvilMod.MODID, n)))));
    }

    // Патроны
    public static final RegistryObject<Item> HANDGUN_AMMO = reg("handgun_ammo", p -> new Item(p));
    public static final RegistryObject<Item> SHOTGUN_SHELLS = reg("shotgun_shells", p -> new Item(p));
    public static final RegistryObject<Item> MAGNUM_AMMO = reg("magnum_ammo", p -> new Item(p));
    // Оружие
    public static final RegistryObject<Item> HANDGUN = reg("handgun", p -> new FirearmItem(p.stacksTo(1), 6f, 1, 0.005f, 8, 50, () -> ModItems.HANDGUN_AMMO.get()));
    public static final RegistryObject<Item> SHOTGUN = reg("shotgun", p -> new FirearmItem(p.stacksTo(1), 3.5f, 8, 0.09f, 30, 16, () -> ModItems.SHOTGUN_SHELLS.get()));
    public static final RegistryObject<Item> MAGNUM = reg("magnum", p -> new FirearmItem(p.stacksTo(1), 20f, 1, 0.0f, 28, 80, () -> ModItems.MAGNUM_AMMO.get()));
    public static final RegistryObject<Item> KNIFE = reg("combat_knife", p -> new Item(p.sword(ToolMaterial.IRON, 3.0f, -1.6f)));
    // Лечение
    public static final RegistryObject<Item> GREEN_HERB = reg("green_herb", p -> new HealItem(p, 6f, false));
    public static final RegistryObject<Item> RED_HERB = reg("red_herb", p -> new Item(p));
    public static final RegistryObject<Item> MIXED_HERB = reg("mixed_herb", p -> new HealItem(p, 14f, false));
    public static final RegistryObject<Item> FIRST_AID_SPRAY = reg("first_aid_spray", p -> new HealItem(p.stacksTo(4), 40f, false));
    public static final RegistryObject<Item> T_VIRUS = reg("t_virus_vial", p -> new HealItem(p.stacksTo(4), 4f, true));
    // Яйца призыва
    public static final RegistryObject<Item> LEON_EGG = reg("leon_spawn_egg", p -> new SpawnEggItem(ModEntities.LEON.get(), p));
    public static final RegistryObject<Item> ADA_EGG = reg("ada_spawn_egg", p -> new SpawnEggItem(ModEntities.ADA.get(), p));
    public static final RegistryObject<Item> JILL_EGG = reg("jill_spawn_egg", p -> new SpawnEggItem(ModEntities.JILL.get(), p));
    public static final RegistryObject<Item> CHRIS_EGG = reg("chris_spawn_egg", p -> new SpawnEggItem(ModEntities.CHRIS.get(), p));
    public static final RegistryObject<Item> WESKER_EGG = reg("wesker_spawn_egg", p -> new SpawnEggItem(ModEntities.WESKER.get(), p));
    public static final RegistryObject<Item> NEMESIS_EGG = reg("nemesis_spawn_egg", p -> new SpawnEggItem(ModEntities.NEMESIS.get(), p));
    public static final RegistryObject<Item> DIMITRESCU_EGG = reg("dimitrescu_spawn_egg", p -> new SpawnEggItem(ModEntities.DIMITRESCU.get(), p));
    public static final RegistryObject<Item> BAKER_EGG = reg("baker_spawn_egg", p -> new SpawnEggItem(ModEntities.BAKER.get(), p));
    public static final RegistryObject<Item> ZOMBIE_EGG = reg("zombie_spawn_egg", p -> new SpawnEggItem(ModEntities.ZOMBIE.get(), p));
}
