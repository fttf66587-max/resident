package com.residentevil;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ResidentEvilMod.MODID);
    public static final RegistryObject<CreativeModeTab> RE_TAB = TABS.register("residentevil", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.residentevil"))
                    .icon(() -> new ItemStack(ModItems.HANDGUN.get()))
                    .displayItems((params, out) -> ModItems.ITEMS.getEntries().forEach(o -> out.accept(o.get())))
                    .build());
}
