package com.residentevil;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Союзный персонаж (Леон, Ада, Джилл, Крис): стреляет по монстрам. Джилл лечит игроков. */
public class RECharacter extends PathfinderMob implements RangedAttackMob {
    private final float dmg; private boolean healer;

    public RECharacter(EntityType<? extends PathfinderMob> t, Level l, float dmg, double speed) {
        super(t, l);
        this.dmg = dmg;
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speed);
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.HANDGUN.get()));
        setPersistenceRequired();
    }
    public RECharacter healer() { this.healer = true; return this; }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 40).add(Attributes.MOVEMENT_SPEED, 0.3).add(Attributes.FOLLOW_RANGE, 32);
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new RangedAttackGoal(this, 1.0, 15, 18f));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }
    @Override public void performRangedAttack(LivingEntity target, float power) {
        Vec3 dir = target.getEyePosition().subtract(getEyePosition()).normalize();
        ModUtil.shoot(this, dir, 32, dmg, 1, 0.02f);
    }
    @Override protected void customServerAiStep(ServerLevel sl) {
        super.customServerAiStep(sl);
        if (healer && tickCount % 300 == 0)
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(8))) p.heal(4f);
    }
}
