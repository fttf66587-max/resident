package com.residentevil.client;

import com.residentevil.ModEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;

public class ClientSetup {
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.LEON.get(), c -> new REHumanoidRenderer<>(c, "leon", 1f));
        e.registerEntityRenderer(ModEntities.ADA.get(), c -> new REHumanoidRenderer<>(c, "ada", 1f));
        e.registerEntityRenderer(ModEntities.JILL.get(), c -> new REHumanoidRenderer<>(c, "jill", 1f));
        e.registerEntityRenderer(ModEntities.CHRIS.get(), c -> new REHumanoidRenderer<>(c, "chris", 1.05f));
        e.registerEntityRenderer(ModEntities.WESKER.get(), c -> new REHumanoidRenderer<>(c, "wesker", 1f));
        e.registerEntityRenderer(ModEntities.NEMESIS.get(), c -> new REHumanoidRenderer<>(c, "nemesis", 1.4f));
        e.registerEntityRenderer(ModEntities.DIMITRESCU.get(), c -> new REHumanoidRenderer<>(c, "dimitrescu", 1.5f));
        e.registerEntityRenderer(ModEntities.BAKER.get(), c -> new REHumanoidRenderer<>(c, "baker", 1.05f));
        e.registerEntityRenderer(ModEntities.ZOMBIE.get(), c -> new REHumanoidRenderer<>(c, "zombie", 1f));
    }
}
