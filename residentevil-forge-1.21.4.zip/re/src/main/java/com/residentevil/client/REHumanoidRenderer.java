package com.residentevil.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.residentevil.ResidentEvilMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/** Человекоподобный рендер со своим скином и масштабом. */
public class REHumanoidRenderer<T extends Mob> extends HumanoidMobRenderer<T, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
    private final ResourceLocation tex;
    private final float scale;

    public REHumanoidRenderer(EntityRendererProvider.Context ctx, String name, float scale) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f * scale);
        this.tex = ResourceLocation.fromNamespaceAndPath(ResidentEvilMod.MODID, "textures/entity/" + name + ".png");
        this.scale = scale;
    }
    @Override public HumanoidRenderState createRenderState() { return new HumanoidRenderState(); }
    @Override public ResourceLocation getTextureLocation(HumanoidRenderState s) { return tex; }
    @Override protected void scale(HumanoidRenderState s, PoseStack ps) { ps.scale(scale, scale, scale); }
}
